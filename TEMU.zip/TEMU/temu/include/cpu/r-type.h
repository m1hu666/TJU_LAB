#ifndef __RTYPE_H__
#define __RTYPE_H__

make_helper(and);
make_helper(addu);
make_helper(or);
make_helper(xor);
make_helper(sll);
make_helper(add);
make_helper(srav);
#endif
