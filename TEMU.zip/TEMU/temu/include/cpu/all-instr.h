#include "r-type.h"
#include "i-type.h"
#include "special.h"
