#define HIT_GOOD_TRAP \
	.word 0x4a000000
